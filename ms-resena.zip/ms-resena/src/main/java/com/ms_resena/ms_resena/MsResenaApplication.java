package com.ms_resena.ms_resena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsResenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsResenaApplication.class, args);
	}

}
