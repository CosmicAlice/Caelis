package com.ms_resena.ms_resena;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsResenaApplicationTests {

	@Test
	void contextLoads() {
	}

}
